document.addEventListener("DOMContentLoaded", () => {
  initFlashAutoDismiss();
  initChoiceGroups();   // segmented chips (estatus, prioridad)
  initTypeCards();      // icon cards (tipo de problema)
  initCharCounters();
  initPasswordToggles();
  initResolverConfirm();
});

/* Auto-desvanece los mensajes flash después de unos segundos */
function initFlashAutoDismiss() {
  document.querySelectorAll(".flash").forEach((el) => {
    setTimeout(() => {
      el.style.transition = "opacity 0.4s ease";
      el.style.opacity = "0";
      setTimeout(() => el.remove(), 450);
    }, 6000);
  });
}

/* Chips tipo "segmented control" que reflejan un <select> oculto real
   (así el formulario sigue funcionando igual del lado del servidor) */
function initChoiceGroups() {
  document.querySelectorAll(".choice-group[data-target]").forEach((group) => {
    const targetSelect = document.getElementById(group.dataset.target);
    if (!targetSelect) return;

    const chips = Array.from(group.querySelectorAll(".choice-chip"));
    const syncActive = () => {
      chips.forEach((chip) => {
        chip.classList.toggle("is-active", chip.dataset.value === targetSelect.value);
      });
    };
    chips.forEach((chip) => {
      chip.addEventListener("click", () => {
        targetSelect.value = chip.dataset.value;
        targetSelect.dispatchEvent(new Event("change"));
        syncActive();
      });
    });
    syncActive();
  });
}

/* Tarjetas con icono para elegir el tipo de problema, reflejan un <select> */
function initTypeCards() {
  document.querySelectorAll(".type-cards[data-target]").forEach((group) => {
    const targetSelect = document.getElementById(group.dataset.target);
    if (!targetSelect) return;

    const cards = Array.from(group.querySelectorAll(".type-card"));
    const syncActive = () => {
      cards.forEach((card) => {
        card.classList.toggle("is-active", card.dataset.value === targetSelect.value);
      });
    };
    cards.forEach((card) => {
      card.addEventListener("click", () => {
        targetSelect.value = card.dataset.value;
        targetSelect.dispatchEvent(new Event("change"));
        syncActive();
      });
    });
    syncActive();
  });
}

/* Contador de caracteres para textareas con data-counter-max */
function initCharCounters() {
  document.querySelectorAll("textarea[data-counter-max]").forEach((textarea) => {
    const max = parseInt(textarea.dataset.counterMax, 10);
    const counter = document.getElementById(textarea.dataset.counterId);
    if (!counter) return;

    const update = () => {
      const len = textarea.value.length;
      counter.textContent = `${len} / ${max} caracteres`;
      counter.classList.toggle("is-near-limit", len > max * 0.9);
    };
    textarea.addEventListener("input", update);
    update();
  });
}

/* Mostrar/ocultar contraseña */
function initPasswordToggles() {
  document.querySelectorAll(".password-toggle[data-target]").forEach((btn) => {
    const input = document.getElementById(btn.dataset.target);
    if (!input) return;
    btn.addEventListener("click", () => {
      const isHidden = input.type === "password";
      input.type = isHidden ? "text" : "password";
      btn.textContent = isHidden ? "Ocultar" : "Mostrar";
    });
  });
}

/* Confirma antes de marcar un ticket como resuelto sin comentario */
function initResolverConfirm() {
  const form = document.getElementById("respuesta-form");
  if (!form) return;
  const estatusSelect = document.getElementById("estatus");
  const comentario = document.getElementById("comentario");

  form.addEventListener("submit", (e) => {
    if (estatusSelect && estatusSelect.value === "resuelto" && !comentario.value.trim()) {
      const seguir = confirm(
        "Vas a marcar este ticket como resuelto sin escribir una respuesta. " +
        "El usuario no recibirá correo si dejas el campo vacío. ¿Continuar de todas formas?"
      );
      if (!seguir) e.preventDefault();
    }
  });
}
